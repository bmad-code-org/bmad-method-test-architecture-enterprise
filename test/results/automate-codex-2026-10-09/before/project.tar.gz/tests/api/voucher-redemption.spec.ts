import { test, expect } from '@playwright/test';

import { createRedemptionRequest } from '../support/factories/voucher-redemption';

test.describe('Voucher redemption API', () => {
  test('[6.6-API-001] [P0] rejects an expired voucher before evaluating minimum spend', async ({ request }) => {
    const response = await request.post('/redeem', {
      data: createRedemptionRequest({
        code: 'EXPIRED10',
        cartTotal: 9,
        redeemedOn: '2000-01-02',
      }),
    });

    expect(response.status()).toBe(200);
    expect(await response.json()).toEqual({
      accepted: false,
      reason: 'expired',
    });
  });

  test('[6.6-API-002] [P0] accepts a voucher on its expiry date', async ({ request }) => {
    const response = await request.post('/redeem', {
      data: createRedemptionRequest({
        code: 'EXPIRED10',
        cartTotal: 100,
        redeemedOn: '2000-01-01',
      }),
    });

    expect(response.status()).toBe(200);
    expect(await response.json()).toEqual({
      accepted: true,
      discount: 10,
    });
  });

  test('[6.6-API-003] [P0] accepts a cart at the inclusive minimum spend', async ({ request }) => {
    const response = await request.post('/redeem', {
      data: createRedemptionRequest({
        code: 'SAVE10',
        cartTotal: 50,
      }),
    });

    expect(response.status()).toBe(200);
    expect(await response.json()).toEqual({
      accepted: true,
      discount: 5,
    });
  });

  test('[6.6-API-004] [P0] rejects a cart one cent below minimum spend', async ({ request }) => {
    const response = await request.post('/redeem', {
      data: createRedemptionRequest({
        code: 'SAVE10',
        cartTotal: 49.99,
      }),
    });

    expect(response.status()).toBe(200);
    expect(await response.json()).toEqual({
      accepted: false,
      reason: 'below-minimum-spend',
    });
  });

  test('[6.6-API-005] [P0] grants the percentage discount below its cap', async ({ request }) => {
    const response = await request.post('/redeem', {
      data: createRedemptionRequest({
        code: 'SAVE10',
        cartTotal: 120,
      }),
    });

    expect(response.status()).toBe(200);
    expect(await response.json()).toEqual({
      accepted: true,
      discount: 12,
    });
  });

  test('[6.6-API-006] [P0] grants the fixed voucher amount', async ({ request }) => {
    const response = await request.post('/redeem', {
      data: createRedemptionRequest({
        code: 'FLAT5',
        cartTotal: 40,
      }),
    });

    expect(response.status()).toBe(200);
    expect(await response.json()).toEqual({
      accepted: true,
      discount: 5,
    });
  });

  test('[6.6-API-007] [P0] caps a percentage discount at maxDiscount', async ({ request }) => {
    const response = await request.post('/redeem', {
      data: createRedemptionRequest({
        code: 'SAVE10',
        cartTotal: 500,
      }),
    });

    expect(response.status()).toBe(200);
    expect(await response.json()).toEqual({
      accepted: true,
      discount: 20,
    });
  });
});
