export type RedemptionRequest = {
  code: 'SAVE10' | 'FLAT5' | 'EXPIRED10';
  cartTotal: number;
  redeemedOn: string;
};

export const createRedemptionRequest = (overrides: Partial<RedemptionRequest> = {}): RedemptionRequest => ({
  code: 'SAVE10',
  cartTotal: 100,
  redeemedOn: '2026-01-15',
  ...overrides,
});
